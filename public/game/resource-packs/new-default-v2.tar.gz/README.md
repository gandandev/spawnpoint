Jappa's New Default: The Beta Collection (1.12.2 Port)
This project is a historical preservation of the early texture redesigns for Minecraft, originally created by Jasper Boerstra (Jappa) and Mojang Studios between 2017 and 2018.

These textures were recovered via Wayback Machine and specifically organized and ported to be natively compatible with Minecraft 1.12.2.

Content Included
Beta V1 (Nov 2017): The first experimental iteration. Features high-contrast textures and the original high-noise Netherrack.

Beta V2 (Jan 2018): The first major refinement. Softer textures, improved ores, and the transition to the modern organic style.

License and Legal
This port is distributed under the Eclipse Public License - v 2.0.

Attribution Requirements
If you modify, redistribute, or use these files in your own projects (such as modpacks, remixes, or derivative works), the following conditions apply:

Original Credits: You must maintain original credits to Mojang Studios and Jappa for the artwork.

Port Credit: You must provide credit to Lissten as the author of this specific 1.12.2 port and preservation project.

License Preservation: Any derivative work based on these files must also be licensed under the EPL 2.0.

Notice: You may not remove this README or any copyright notices included in the metadata.

Installation
Move the .zip file into your resourcepacks folder.

Activate the pack in the Minecraft Resource Packs menu.

If a Version Incompatibility warning appears, it can be safely ignored; the pack is fully functional on 1.12.2.

Preserved and Ported by Lissten